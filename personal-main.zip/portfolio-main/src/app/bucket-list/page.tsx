import BucketListContainer from '@/components/BucketListContainer'

export default function BucketListPage() {
  return <BucketListContainer />
}
